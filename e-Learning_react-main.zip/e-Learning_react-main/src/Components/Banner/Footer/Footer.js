import React from 'react';
import Style from './Footer.css'

const Footer = () => {
    return (
        <div className='footer'>
            <p>&copy; Copyright 2021 farjana fariha.net - e-Learning Theme</p>
        </div>
    );
};

export default Footer;