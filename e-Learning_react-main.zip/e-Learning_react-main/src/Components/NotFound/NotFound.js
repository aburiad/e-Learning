import React from 'react';

const NotFound = () => {
    return (
        <div>
            <h2>Page not found</h2>
        </div>
    );
};

export default NotFound;