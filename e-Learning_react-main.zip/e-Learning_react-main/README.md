Project Title: 📛  Educational Website
The name of the project : web Tech
Live Link / Demo Link: 🔗https://cranky-mcnulty-bc7090.netlify.app/
The concepts "text" and "text activity" are gradually expanding the area of their application. 

Table of Content: 📑

About the Project: 📚


Technologies Used: ☕️ 🐍 ⚛️
React js, Javascript

Setup / Installation: 💻
install npm create-react-app my-app
install npm install 

Approach: 🚶
I have used Bootstrap for design.

Credits: 📝
Programming Hero Team
